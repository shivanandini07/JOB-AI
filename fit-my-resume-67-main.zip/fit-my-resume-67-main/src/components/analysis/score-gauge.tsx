import { motion } from "framer-motion";

export function ScoreGauge({ value, size = 200 }: { value: number; size?: number }) {
  const v = Math.max(0, Math.min(100, value));
  const r = size / 2 - 12;
  const c = 2 * Math.PI * r;
  const offset = c - (v / 100) * c;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="oklch(0.58 0.24 265)" />
            <stop offset="100%" stopColor="oklch(0.62 0.22 300)" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} strokeWidth="14" stroke="var(--muted)" fill="none" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r}
          strokeWidth="14"
          strokeLinecap="round"
          stroke="url(#gaugeGrad)"
          fill="none"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-5xl font-bold gradient-text">{v}</div>
        <div className="text-xs uppercase tracking-widest text-muted-foreground">ATS Score</div>
      </div>
    </div>
  );
}