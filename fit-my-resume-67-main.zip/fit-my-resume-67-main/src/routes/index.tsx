import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Sparkles,
  Target,
  BarChart3,
  BrainCircuit,
  FileSearch,
  MessagesSquare,
  GraduationCap,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { LandingNav } from "@/components/landing-nav";

export const Route = createFileRoute("/")({
  component: Landing,
});

const features = [
  { icon: Target, title: "ATS Match Score", desc: "See how well your resume ranks against any job in seconds — keyword, skill and semantic scoring combined." },
  { icon: FileSearch, title: "Keyword & Skill Gap", desc: "Discover exactly which technical and soft skills you're missing before recruiters do." },
  { icon: BrainCircuit, title: "Semantic Similarity", desc: "GPT-powered contextual analysis explains why your score is what it is." },
  { icon: Sparkles, title: "STAR Bullet Rewriter", desc: "Turn weak bullets into recruiter-ready achievements with strong action verbs and metrics." },
  { icon: MessagesSquare, title: "Interview Question Bank", desc: "HR, technical, behavioral and project-based questions tailored to each job." },
  { icon: GraduationCap, title: "Learning Roadmap", desc: "Curated courses, certifications and projects to close every skill gap." },
];

const benefits = [
  "Pass more ATS screenings on the first try",
  "Get recruiter-level feedback in under 30 seconds",
  "Tailor your resume for every application",
  "Walk into interviews knowing exactly what to expect",
  "Track and compare every version of your resume",
  "Level up with a personalized skill roadmap",
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <LandingNav />

      {/* Hero */}
      <section className="relative hero-bg overflow-hidden">
        <div className="mx-auto max-w-6xl px-6 pt-24 pb-32 md:pt-32 md:pb-40 text-center">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-sm text-muted-foreground mb-6"
          >
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            AI-powered resume intelligence
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.05 }}
            className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]"
          >
            Land the role you deserve <br />
            with <span className="gradient-text">JobFit AI</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground"
          >
            Upload your resume and any job description. Get an ATS score, keyword gap
            analysis, rewritten bullets, tailored interview prep and a personal learning
            roadmap — all in under 30 seconds.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-10 flex flex-wrap items-center justify-center gap-3"
          >
            <Button asChild size="lg" className="gradient-brand text-brand-foreground shadow-glow border-0 h-12 px-6">
              <Link to="/auth">
                Analyze my resume free <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-12 px-6 glass">
              <a href="#features">See how it works</a>
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="mt-16 mx-auto max-w-4xl"
          >
            <div className="glass-strong rounded-3xl p-1 shadow-glow">
              <div className="rounded-[calc(var(--radius)+8px)] bg-card p-6 md:p-10">
                <div className="grid md:grid-cols-3 gap-6 text-left">
                  <StatCard label="ATS Score" value="87" gradient />
                  <StatCard label="Keyword Match" value="72%" />
                  <StatCard label="Skills Gap" value="4 missing" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-6 py-24">
        <div className="text-center mb-14">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            Everything you need to <span className="gradient-text">get hired</span>
          </h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Fourteen recruiter-grade tools in one place. Purpose-built for students and
            professionals targeting top tech companies.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="glass rounded-2xl p-6 hover:shadow-glow transition-shadow"
            >
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl gradient-brand text-brand-foreground mb-4">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Benefits */}
      <section className="relative py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="glass-strong rounded-3xl p-8 md:p-14 grid md:grid-cols-2 gap-10 items-center">
            <div>
              <h2 className="text-4xl font-bold tracking-tight">
                Built for the <span className="gradient-text">top 1% of applicants</span>
              </h2>
              <p className="mt-4 text-muted-foreground">
                Whether you're targeting Google, Microsoft, Amazon, NVIDIA or your first
                internship — JobFit AI treats every application like a recruiter would.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Badge icon={ShieldCheck}>Private &amp; secure</Badge>
                <Badge icon={BarChart3}>Recruiter-grade</Badge>
                <Badge icon={Sparkles}>Powered by GPT-5.5</Badge>
              </div>
            </div>
            <ul className="space-y-3">
              {benefits.map((b) => (
                <li key={b} className="flex items-start gap-3 text-sm">
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-6 py-24 text-center">
        <div className="glass-strong rounded-3xl p-12 shadow-glow">
          <h2 className="text-4xl font-bold tracking-tight">
            Your next interview is 30 seconds away
          </h2>
          <p className="mt-4 text-muted-foreground">
            Free forever for your first analysis. No credit card required.
          </p>
          <Button asChild size="lg" className="mt-8 gradient-brand text-brand-foreground shadow-glow border-0 h-12 px-8">
            <Link to="/auth">Get started free <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
      </section>

      <footer className="border-t border-border/60">
        <div className="mx-auto max-w-6xl px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded-md gradient-brand" />
            <span className="font-semibold text-foreground">JobFit AI</span>
            <span>· © {new Date().getFullYear()}</span>
          </div>
          <div className="flex gap-6">
            <a href="#features" className="hover:text-foreground">Features</a>
            <Link to="/auth" className="hover:text-foreground">Sign in</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

function StatCard({ label, value, gradient }: { label: string; value: string; gradient?: boolean }) {
  return (
    <div className="rounded-2xl border border-border/60 p-5 bg-background/60">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-2 text-4xl font-bold ${gradient ? "gradient-text" : ""}`}>{value}</div>
    </div>
  );
}

function Badge({ icon: Icon, children }: { icon: typeof ShieldCheck; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs">
      <Icon className="h-3.5 w-3.5 text-primary" />
      {children}
    </span>
  );
}
