import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Upload, FileText, Sparkles, Loader2, X, FileCheck2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { extractTextFromFile } from "@/lib/pdf-parser";
import { runAnalysis } from "@/lib/analyze.functions";

export const Route = createFileRoute("/_authenticated/analyze")({
  head: () => ({ meta: [{ title: "New Analysis — JobFit AI" }] }),
  component: AnalyzePage,
});

function AnalyzePage() {
  const navigate = useNavigate();
  const runFn = useServerFn(runAnalysis);
  const [resumeText, setResumeText] = useState("");
  const [resumeName, setResumeName] = useState<string | null>(null);
  const [parsing, setParsing] = useState(false);
  const [jdText, setJdText] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [running, setRunning] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const onFile = useCallback(async (file: File) => {
    if (file.size > 10 * 1024 * 1024) {
      toast.error("File too large (10 MB max)");
      return;
    }
    setParsing(true);
    try {
      const text = await extractTextFromFile(file);
      setResumeText(text);
      setResumeName(file.name);
      toast.success(`Parsed ${file.name}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to parse file");
    } finally {
      setParsing(false);
    }
  }, []);

  const onJdFile = useCallback(async (file: File) => {
    setParsing(true);
    try {
      const text = await extractTextFromFile(file);
      setJdText(text);
      toast.success(`Loaded ${file.name}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to parse file");
    } finally {
      setParsing(false);
    }
  }, []);

  async function run() {
    if (resumeText.trim().length < 50) {
      toast.error("Please upload or paste a longer resume");
      return;
    }
    if (jdText.trim().length < 30) {
      toast.error("Please paste a job description");
      return;
    }
    setRunning(true);
    try {
      const res = await runFn({
        data: {
          resume_text: resumeText,
          job_description: jdText,
          job_title: jobTitle || undefined,
          save: true,
        },
      });
      toast.success("Analysis complete!");
      if (res.analysisId) navigate({ to: "/analysis/$id", params: { id: res.analysisId } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Analysis failed");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl p-6 md:p-10 space-y-8">
      <div>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">New Analysis</h1>
        <p className="text-muted-foreground mt-2">
          Upload your resume + paste a job description. We'll do the rest.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Resume upload */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="glass-strong rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="h-8 w-8 rounded-lg gradient-brand grid place-items-center">
              <FileText className="h-4 w-4 text-brand-foreground" />
            </div>
            <h2 className="text-lg font-semibold">Your resume</h2>
          </div>

          <label
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const f = e.dataTransfer.files[0];
              if (f) onFile(f);
            }}
            className={`block cursor-pointer rounded-2xl border-2 border-dashed p-6 text-center transition-colors ${
              dragOver ? "border-primary bg-accent/50" : "border-border hover:border-primary/60"
            }`}
          >
            <input
              type="file"
              accept=".pdf,.txt,.md"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
            />
            {resumeName ? (
              <div className="flex items-center justify-center gap-2 text-sm">
                <FileCheck2 className="h-4 w-4 text-primary" />
                <span className="font-medium">{resumeName}</span>
                <button
                  type="button"
                  onClick={(e) => { e.preventDefault(); setResumeName(null); setResumeText(""); }}
                  className="ml-2 text-muted-foreground hover:text-destructive"
                  aria-label="Remove"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : parsing ? (
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Parsing PDF…
              </div>
            ) : (
              <>
                <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <div className="text-sm font-medium">Drop PDF or click to upload</div>
                <div className="text-xs text-muted-foreground mt-1">PDF or TXT · up to 10 MB</div>
              </>
            )}
          </label>

          <div className="mt-4">
            <Label className="text-xs">Or paste resume text</Label>
            <Textarea
              value={resumeText}
              onChange={(e) => setResumeText(e.target.value)}
              rows={6}
              placeholder="Paste your resume text here…"
              className="mt-1"
            />
          </div>
        </motion.div>

        {/* JD */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="glass-strong rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="h-8 w-8 rounded-lg gradient-brand grid place-items-center">
              <Sparkles className="h-4 w-4 text-brand-foreground" />
            </div>
            <h2 className="text-lg font-semibold">Job description</h2>
          </div>

          <div className="mb-3">
            <Label className="text-xs" htmlFor="jobtitle">Job title (optional)</Label>
            <Input
              id="jobtitle"
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              placeholder="e.g. Senior Machine Learning Engineer"
              maxLength={140}
              className="mt-1"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Description</Label>
              <label className="text-xs text-primary hover:underline cursor-pointer">
                Upload PDF/TXT
                <input
                  type="file"
                  className="hidden"
                  accept=".pdf,.txt,.md"
                  onChange={(e) => e.target.files?.[0] && onJdFile(e.target.files[0])}
                />
              </label>
            </div>
            <Textarea
              value={jdText}
              onChange={(e) => setJdText(e.target.value)}
              rows={12}
              placeholder="Paste the full job description here…"
            />
          </div>
        </motion.div>
      </div>

      <div className="flex justify-end">
        <Button
          onClick={run}
          disabled={running || parsing}
          size="lg"
          className="gradient-brand text-brand-foreground border-0 shadow-glow h-12 px-8"
        >
          {running ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing with GPT-5.5…</>
          ) : (
            <><Sparkles className="mr-2 h-4 w-4" /> Run analysis</>
          )}
        </Button>
      </div>
    </div>
  );
}