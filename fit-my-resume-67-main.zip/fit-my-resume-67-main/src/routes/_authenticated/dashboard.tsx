import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listAnalyses } from "@/lib/analyses.functions";
import { motion } from "framer-motion";
import { ArrowRight, Upload, Sparkles, TrendingUp, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — JobFit AI" }] }),
  component: Dashboard,
});

function Dashboard() {
  const listFn = useServerFn(listAnalyses);
  const { data: analyses = [], isLoading } = useQuery({ queryKey: ["analyses"], queryFn: () => listFn() });

  const avg = analyses.length
    ? Math.round(analyses.reduce((s, a) => s + (a.ats_score ?? 0), 0) / analyses.length)
    : 0;
  const best = analyses.length ? Math.max(...analyses.map((a) => a.ats_score ?? 0)) : 0;

  return (
    <div className="mx-auto max-w-6xl p-6 md:p-10 space-y-8">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
          Welcome back <span className="gradient-text">👋</span>
        </h1>
        <p className="text-muted-foreground mt-2">
          Upload a resume and paste any job description to get a full recruiter-grade analysis.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-4">
        <MetricCard icon={FileText} label="Analyses run" value={String(analyses.length)} />
        <MetricCard icon={TrendingUp} label="Average ATS score" value={String(avg)} gradient />
        <MetricCard icon={Sparkles} label="Best score" value={String(best)} />
      </div>

      <div className="glass-strong rounded-3xl p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-glow">
        <div>
          <h2 className="text-2xl font-bold">Start a new analysis</h2>
          <p className="text-muted-foreground mt-1">
            Drop your resume PDF + a job description. Results in ~30 seconds.
          </p>
        </div>
        <Button asChild size="lg" className="gradient-brand text-brand-foreground border-0 shadow-glow">
          <Link to="/analyze">
            <Upload className="mr-1 h-4 w-4" /> New analysis <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Recent analyses</h2>
          <Button asChild variant="ghost" size="sm">
            <Link to="/history">View all →</Link>
          </Button>
        </div>
        {isLoading ? (
          <div className="glass rounded-2xl p-8 text-center text-muted-foreground">Loading…</div>
        ) : analyses.length === 0 ? (
          <div className="glass rounded-2xl p-12 text-center">
            <div className="mx-auto h-14 w-14 rounded-2xl gradient-brand grid place-items-center shadow-glow mb-4">
              <Sparkles className="h-6 w-6 text-brand-foreground" />
            </div>
            <p className="text-lg font-medium">No analyses yet</p>
            <p className="text-muted-foreground text-sm mt-1">Run your first analysis to see it here.</p>
            <Button asChild className="mt-6 gradient-brand text-brand-foreground border-0">
              <Link to="/analyze">Get started</Link>
            </Button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-3">
            {analyses.slice(0, 6).map((a) => (
              <Link
                key={a.id}
                to="/analysis/$id"
                params={{ id: a.id }}
                className="glass rounded-2xl p-5 hover:shadow-glow transition-shadow group"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="font-semibold truncate">{a.title}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {format(new Date(a.created_at), "PP · p")}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-2xl font-bold gradient-text">{a.ats_score ?? "—"}</div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">ATS</div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, gradient }: { icon: typeof Upload; label: string; value: string; gradient?: boolean }) {
  return (
    <div className="glass rounded-2xl p-5 flex items-center gap-4">
      <div className="h-11 w-11 rounded-xl gradient-brand grid place-items-center text-brand-foreground shrink-0">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className={`text-3xl font-bold ${gradient ? "gradient-text" : ""}`}>{value}</div>
      </div>
    </div>
  );
}