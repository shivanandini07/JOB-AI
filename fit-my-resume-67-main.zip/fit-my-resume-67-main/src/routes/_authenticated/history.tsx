import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listAnalyses, deleteAnalysis } from "@/lib/analyses.functions";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({ meta: [{ title: "History — JobFit AI" }] }),
  component: HistoryPage,
});

function HistoryPage() {
  const listFn = useServerFn(listAnalyses);
  const delFn = useServerFn(deleteAnalysis);
  const qc = useQueryClient();
  const { data: analyses = [], isLoading } = useQuery({ queryKey: ["analyses"], queryFn: () => listFn() });
  const mut = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["analyses"] }); toast.success("Deleted"); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to delete"),
  });

  return (
    <div className="mx-auto max-w-5xl p-6 md:p-10 space-y-6">
      <h1 className="text-3xl md:text-4xl font-bold tracking-tight">History</h1>
      <p className="text-muted-foreground">All your saved analyses.</p>

      {isLoading ? (
        <div className="glass rounded-2xl p-8 text-center text-muted-foreground">Loading…</div>
      ) : analyses.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center text-muted-foreground">
          Nothing saved yet. <Link to="/analyze" className="text-primary hover:underline">Run your first analysis →</Link>
        </div>
      ) : (
        <div className="grid gap-3">
          {analyses.map((a) => (
            <div key={a.id} className="glass rounded-2xl p-5 flex items-center gap-4">
              <div className="text-3xl font-bold gradient-text w-16 text-center">{a.ats_score ?? "—"}</div>
              <div className="flex-1 min-w-0">
                <Link to="/analysis/$id" params={{ id: a.id }} className="font-semibold truncate block hover:underline">
                  {a.title}
                </Link>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {format(new Date(a.created_at), "PPP · p")}
                </div>
              </div>
              <Button asChild variant="outline" size="sm">
                <Link to="/analysis/$id" params={{ id: a.id }}>Open</Link>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (confirm("Delete this analysis?")) mut.mutate(a.id);
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}