import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import { useServerFn } from "@tanstack/react-start";
import { careerChat } from "@/lib/analyses.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Bot, User, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/advisor")({
  head: () => ({ meta: [{ title: "Career Advisor — JobFit AI" }] }),
  component: AdvisorPage,
});

type Msg = { role: "user" | "assistant"; content: string };

function AdvisorPage() {
  const chatFn = useServerFn(careerChat);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! I'm your AI career advisor. Ask me anything about resumes, interviews, or career growth." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const res = await chatFn({ data: { messages: next } });
      setMessages([...next, { role: "assistant", content: res.content }]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Chat failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl p-6 md:p-10 flex flex-col h-[calc(100vh-3.5rem)]">
      <div className="mb-4">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Career Advisor</h1>
        <p className="text-muted-foreground text-sm">Powered by GPT-5.5</p>
      </div>

      <div className="flex-1 overflow-y-auto glass-strong rounded-2xl p-6 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
            {m.role === "assistant" && (
              <div className="h-8 w-8 rounded-lg gradient-brand grid place-items-center shrink-0">
                <Bot className="h-4 w-4 text-brand-foreground" />
              </div>
            )}
            <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${m.role === "user" ? "gradient-brand text-brand-foreground" : "bg-muted"}`}>
              <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1">
                <ReactMarkdown>{m.content}</ReactMarkdown>
              </div>
            </div>
            {m.role === "user" && (
              <div className="h-8 w-8 rounded-lg bg-secondary grid place-items-center shrink-0">
                <User className="h-4 w-4" />
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="h-8 w-8 rounded-lg gradient-brand grid place-items-center shrink-0">
              <Bot className="h-4 w-4 text-brand-foreground" />
            </div>
            <div className="bg-muted rounded-2xl px-4 py-3">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); send(); }}
        className="mt-4 flex gap-2"
      >
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about resumes, interviews, career moves…"
          disabled={loading}
          maxLength={2000}
        />
        <Button type="submit" disabled={loading || !input.trim()} className="gradient-brand text-brand-foreground border-0">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}