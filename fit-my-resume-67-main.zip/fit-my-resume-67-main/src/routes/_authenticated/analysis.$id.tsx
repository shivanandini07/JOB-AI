import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getAnalysis } from "@/lib/analyses.functions";
import type { AnalysisResult } from "@/lib/analysis-types";
import { motion } from "framer-motion";
import {
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, Legend,
} from "recharts";
import { ScoreGauge } from "@/components/analysis/score-gauge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Download, CheckCircle2, XCircle, Sparkles, MessagesSquare, GraduationCap,
  Wrench, Tags, FileText, Star,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/analysis/$id")({
  head: () => ({ meta: [{ title: "Analysis — JobFit AI" }] }),
  component: AnalysisPage,
});

function AnalysisPage() {
  const { id } = Route.useParams();
  const getFn = useServerFn(getAnalysis);
  const { data, isLoading, error } = useQuery({
    queryKey: ["analysis", id],
    queryFn: () => getFn({ data: { id } }),
  });

  if (isLoading) return <div className="p-10 text-muted-foreground">Loading…</div>;
  if (error || !data) return <div className="p-10 text-destructive">Failed to load.</div>;

  const r = data.result as unknown as AnalysisResult;

  return (
    <div className="mx-auto max-w-6xl p-6 md:p-10 space-y-8">
      <Header title={data.title} jobTitle={data.job_title ?? ""} result={r} rawData={data} />
      <Overview r={r} />

      <Tabs defaultValue="keywords">
        <TabsList className="glass w-full flex flex-wrap h-auto">
          <TabsTrigger value="keywords"><Tags className="h-3.5 w-3.5 mr-1" />Keywords</TabsTrigger>
          <TabsTrigger value="skills"><Wrench className="h-3.5 w-3.5 mr-1" />Skills</TabsTrigger>
          <TabsTrigger value="feedback"><Sparkles className="h-3.5 w-3.5 mr-1" />Feedback</TabsTrigger>
          <TabsTrigger value="rewrites"><FileText className="h-3.5 w-3.5 mr-1" />Rewrites</TabsTrigger>
          <TabsTrigger value="interview"><MessagesSquare className="h-3.5 w-3.5 mr-1" />Interview</TabsTrigger>
          <TabsTrigger value="roadmap"><GraduationCap className="h-3.5 w-3.5 mr-1" />Roadmap</TabsTrigger>
          <TabsTrigger value="resume"><Star className="h-3.5 w-3.5 mr-1" />Resume</TabsTrigger>
        </TabsList>

        <TabsContent value="keywords" className="mt-6"><KeywordsTab r={r} /></TabsContent>
        <TabsContent value="skills" className="mt-6"><SkillsTab r={r} /></TabsContent>
        <TabsContent value="feedback" className="mt-6"><FeedbackTab r={r} /></TabsContent>
        <TabsContent value="rewrites" className="mt-6"><RewritesTab r={r} /></TabsContent>
        <TabsContent value="interview" className="mt-6"><InterviewTab r={r} /></TabsContent>
        <TabsContent value="roadmap" className="mt-6"><RoadmapTab r={r} /></TabsContent>
        <TabsContent value="resume" className="mt-6"><ResumeTab r={r} /></TabsContent>
      </Tabs>
    </div>
  );
}

function Header({ title, jobTitle, result, rawData }: { title: string; jobTitle: string; result: AnalysisResult; rawData: unknown }) {
  function downloadJSON() {
    const blob = new Blob([JSON.stringify(rawData, null, 2)], { type: "application/json" });
    triggerDownload(blob, `${sanitize(title)}.json`);
  }
  function downloadCSV() {
    const rows = [
      ["Metric", "Value"],
      ["ATS Score", result.ats_score],
      ["Keyword Match", result.keyword_match],
      ["Semantic Similarity", result.semantic_similarity],
      ["Skills Match", result.skills_match],
      ["Experience Match", result.experience_match],
      ["Readability", result.readability_score],
      ["Interview Readiness", result.interview_readiness],
      ["Missing Keywords", (result.missing_keywords || []).join("; ")],
      ["Matched Keywords", (result.matched_keywords || []).join("; ")],
      ["Strengths", (result.strengths || []).join(" | ")],
      ["Weaknesses", (result.weaknesses || []).join(" | ")],
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    triggerDownload(new Blob([csv], { type: "text/csv" }), `${sanitize(title)}.csv`);
  }
  function downloadPDF() {
    // simple print-to-PDF using browser print
    window.print();
    toast.message("Use your browser's Save-as-PDF option in the print dialog.");
  }
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col md:flex-row md:items-end gap-4 justify-between">
      <div>
        <div className="text-xs uppercase tracking-widest text-muted-foreground">Analysis</div>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">{title}</h1>
        {jobTitle && <p className="text-muted-foreground mt-1">Target role: {jobTitle}</p>}
      </div>
      <div className="flex gap-2 print:hidden">
        <Button variant="outline" size="sm" onClick={downloadJSON}><Download className="h-4 w-4 mr-1" />JSON</Button>
        <Button variant="outline" size="sm" onClick={downloadCSV}><Download className="h-4 w-4 mr-1" />CSV</Button>
        <Button size="sm" className="gradient-brand text-brand-foreground border-0" onClick={downloadPDF}><Download className="h-4 w-4 mr-1" />PDF</Button>
      </div>
    </motion.div>
  );
}

function sanitize(s: string) { return s.replace(/[^a-z0-9-_]+/gi, "_").slice(0, 60); }
function triggerDownload(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function Overview({ r }: { r: AnalysisResult }) {
  const radarData = [
    { subject: "Keyword", A: r.keyword_match },
    { subject: "Semantic", A: r.semantic_similarity },
    { subject: "Skills", A: r.skills_match },
    { subject: "Experience", A: r.experience_match },
    { subject: "Readability", A: r.readability_score },
    { subject: "Interview", A: r.interview_readiness },
  ];
  return (
    <div className="grid lg:grid-cols-[auto_1fr] gap-8 glass-strong rounded-3xl p-8 shadow-glow">
      <div className="flex flex-col items-center gap-4">
        <ScoreGauge value={r.ats_score ?? 0} />
        <RecommendationBadge score={r.ats_score ?? 0} />
      </div>
      <div className="space-y-4">
        <div>
          <h3 className="font-semibold mb-1">Why this score</h3>
          <p className="text-sm text-muted-foreground">{r.semantic_explanation}</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <SubScore label="Keyword match" value={r.keyword_match} />
          <SubScore label="Semantic similarity" value={r.semantic_similarity} />
          <SubScore label="Skills match" value={r.skills_match} />
          <SubScore label="Experience match" value={r.experience_match} />
        </div>
        <div className="h-56">
          <ResponsiveContainer>
            <RadarChart data={radarData}>
              <PolarGrid stroke="var(--border)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
              <Radar dataKey="A" stroke="var(--chart-1)" fill="var(--chart-1)" fillOpacity={0.4} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function RecommendationBadge({ score }: { score: number }) {
  const label = score >= 80 ? "Strong hire" : score >= 65 ? "Interview recommended" : score >= 50 ? "Needs work" : "Major gaps";
  const color = score >= 80 ? "bg-success/20 text-success" : score >= 65 ? "bg-primary/20 text-primary" : score >= 50 ? "bg-warning/20 text-warning-foreground" : "bg-destructive/20 text-destructive";
  return <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>{label}</span>;
}

function SubScore({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-semibold">{value ?? 0}%</span>
      </div>
      <Progress value={value ?? 0} className="h-2" />
    </div>
  );
}

function KeywordsTab({ r }: { r: AnalysisResult }) {
  const chartData = [
    { name: "Matched", value: r.matched_keywords?.length ?? 0 },
    { name: "Missing", value: r.missing_keywords?.length ?? 0 },
    { name: "High priority", value: r.high_priority_keywords?.length ?? 0 },
  ];
  const COLORS = ["var(--chart-5)", "var(--destructive)", "var(--chart-2)"];
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="glass rounded-2xl p-6">
        <h3 className="font-semibold mb-4">Keyword distribution</h3>
        <div className="h-64">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={chartData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} label>
                {chartData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Legend />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="glass rounded-2xl p-6 space-y-4">
        <KeywordCloud title="Matched" items={r.matched_keywords} tone="success" />
        <KeywordCloud title="Missing" items={r.missing_keywords} tone="destructive" />
        <KeywordCloud title="High priority" items={r.high_priority_keywords} tone="brand" />
      </div>
    </div>
  );
}

function KeywordCloud({ title, items, tone }: { title: string; items?: string[]; tone: "success" | "destructive" | "brand" }) {
  const cls = tone === "success" ? "bg-success/15 text-success border-success/30"
    : tone === "destructive" ? "bg-destructive/15 text-destructive border-destructive/30"
    : "bg-primary/15 text-primary border-primary/30";
  return (
    <div>
      <h4 className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{title} ({items?.length ?? 0})</h4>
      <div className="flex flex-wrap gap-1.5">
        {(items ?? []).length === 0 && <span className="text-xs text-muted-foreground">None</span>}
        {(items ?? []).map((k, i) => (
          <span key={i} className={`text-xs px-2 py-1 rounded-md border ${cls}`}>{k}</span>
        ))}
      </div>
    </div>
  );
}

function SkillsTab({ r }: { r: AnalysisResult }) {
  const data = [
    { type: "Technical (matched)", n: r.technical_skills?.matched?.length ?? 0 },
    { type: "Technical (missing)", n: r.technical_skills?.missing?.length ?? 0 },
    { type: "Soft (matched)", n: r.soft_skills?.matched?.length ?? 0 },
    { type: "Soft (missing)", n: r.soft_skills?.missing?.length ?? 0 },
  ];
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="glass rounded-2xl p-6">
        <h3 className="font-semibold mb-4">Skills breakdown</h3>
        <div className="h-64">
          <ResponsiveContainer>
            <BarChart data={data}>
              <XAxis dataKey="type" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />
              <YAxis tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />
              <Tooltip />
              <Bar dataKey="n" fill="var(--chart-1)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="glass rounded-2xl p-6 space-y-4">
        <KeywordCloud title="Technical — matched" items={r.technical_skills?.matched} tone="success" />
        <KeywordCloud title="Technical — missing" items={r.technical_skills?.missing} tone="destructive" />
        <KeywordCloud title="Soft — matched" items={r.soft_skills?.matched} tone="success" />
        <KeywordCloud title="Soft — missing" items={r.soft_skills?.missing} tone="destructive" />
      </div>
    </div>
  );
}

function FeedbackTab({ r }: { r: AnalysisResult }) {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <FeedbackList title="Strengths" items={r.strengths} icon={CheckCircle2} tone="success" />
      <FeedbackList title="Weaknesses" items={r.weaknesses} icon={XCircle} tone="destructive" />
      <FeedbackList title="Formatting issues" items={r.formatting_issues} icon={XCircle} tone="warning" />
      <FeedbackList title="ATS compatibility" items={r.ats_compatibility} icon={CheckCircle2} tone="brand" />
      <div className="md:col-span-2 glass rounded-2xl p-6">
        <h3 className="font-semibold mb-3">Recruiter recommendation</h3>
        <p className="text-sm text-muted-foreground">{r.recruiter_recommendation}</p>
        {r.grammar_notes?.length > 0 && (
          <div className="mt-4">
            <h4 className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Grammar notes</h4>
            <ul className="list-disc pl-5 text-sm space-y-1">
              {r.grammar_notes.map((g, i) => <li key={i}>{g}</li>)}
            </ul>
          </div>
        )}
      </div>
      <div className="md:col-span-2 glass rounded-2xl p-6">
        <h3 className="font-semibold mb-3">Suggestions</h3>
        <ul className="space-y-2 text-sm">
          {(r.suggestions ?? []).map((s, i) => (
            <li key={i} className="flex gap-2">
              <Sparkles className="h-4 w-4 text-primary shrink-0 mt-0.5" />
              <span>{s}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function FeedbackList({ title, items, icon: Icon, tone }: { title: string; items?: string[]; icon: typeof CheckCircle2; tone: "success" | "destructive" | "warning" | "brand" }) {
  const colorMap: Record<string, string> = {
    success: "text-success",
    destructive: "text-destructive",
    warning: "text-warning",
    brand: "text-primary",
  };
  return (
    <div className="glass rounded-2xl p-6">
      <h3 className="font-semibold mb-3">{title}</h3>
      <ul className="space-y-2 text-sm">
        {(items ?? []).length === 0 && <li className="text-muted-foreground text-xs">None found.</li>}
        {(items ?? []).map((item, i) => (
          <li key={i} className="flex gap-2">
            <Icon className={`h-4 w-4 shrink-0 mt-0.5 ${colorMap[tone]}`} />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function RewritesTab({ r }: { r: AnalysisResult }) {
  return (
    <div className="space-y-6">
      <div className="glass rounded-2xl p-6">
        <h3 className="font-semibold mb-3">ATS-friendly professional summary</h3>
        <p className="text-sm leading-relaxed">{r.summary}</p>
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-semibold mb-4">STAR bullet rewrites</h3>
        <div className="space-y-4">
          {(r.rewritten_bullets ?? []).map((b, i) => (
            <div key={i} className="grid md:grid-cols-2 gap-4">
              <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
                <div className="text-xs uppercase tracking-wider text-destructive mb-2">Before</div>
                <p className="text-sm">{b.original}</p>
              </div>
              <div className="rounded-xl border border-success/30 bg-success/5 p-4">
                <div className="text-xs uppercase tracking-wider text-success mb-2">After</div>
                <p className="text-sm">{b.improved}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function InterviewTab({ r }: { r: AnalysisResult }) {
  const q = r.interview_questions || ({} as AnalysisResult["interview_questions"]);
  const cats: { key: keyof AnalysisResult["interview_questions"]; label: string }[] = [
    { key: "hr", label: "HR" },
    { key: "technical", label: "Technical" },
    { key: "python", label: "Python" },
    { key: "sql", label: "SQL" },
    { key: "machine_learning", label: "ML" },
    { key: "behavioral", label: "Behavioral" },
    { key: "project_based", label: "Project" },
  ];
  return (
    <Tabs defaultValue="hr">
      <TabsList className="flex flex-wrap h-auto">
        {cats.map((c) => <TabsTrigger key={c.key} value={c.key}>{c.label}</TabsTrigger>)}
      </TabsList>
      {cats.map((c) => (
        <TabsContent key={c.key} value={c.key} className="mt-4 space-y-3">
          {(q[c.key] ?? []).length === 0 && <div className="text-sm text-muted-foreground">No questions.</div>}
          {(q[c.key] ?? []).map((it, i) => (
            <div key={i} className="glass rounded-2xl p-5">
              <div className="flex justify-between gap-3 items-start">
                <p className="font-medium">{it.question}</p>
                <Badge variant={it.difficulty === "hard" ? "destructive" : it.difficulty === "medium" ? "default" : "secondary"} className="capitalize shrink-0">
                  {it.difficulty}
                </Badge>
              </div>
              {it.suggested_answer && (
                <p className="mt-2 text-sm text-muted-foreground">{it.suggested_answer}</p>
              )}
            </div>
          ))}
        </TabsContent>
      ))}
    </Tabs>
  );
}

function RoadmapTab({ r }: { r: AnalysisResult }) {
  return (
    <div className="space-y-4">
      {(r.learning_roadmap ?? []).length === 0 && <div className="text-sm text-muted-foreground">No roadmap.</div>}
      {(r.learning_roadmap ?? []).map((it, i) => (
        <div key={i} className="glass rounded-2xl p-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl gradient-brand grid place-items-center text-brand-foreground font-bold">{i + 1}</div>
            <div>
              <h3 className="font-semibold text-lg">{it.skill}</h3>
              <p className="text-sm text-muted-foreground">{it.why}</p>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-4 mt-4 text-sm">
            <List title="Courses" items={it.courses} />
            <List title="Certifications" items={it.certifications} />
            <List title="Projects" items={it.projects} />
            <List title="Docs" items={it.docs} />
            <List title="Books" items={it.books} />
          </div>
        </div>
      ))}
    </div>
  );
}
function List({ title, items }: { title: string; items?: string[] }) {
  if (!items?.length) return null;
  return (
    <div>
      <h4 className="text-xs uppercase tracking-wider text-muted-foreground mb-1">{title}</h4>
      <ul className="list-disc pl-5 space-y-0.5">{items.map((x, i) => <li key={i}>{x}</li>)}</ul>
    </div>
  );
}

function ResumeTab({ r }: { r: AnalysisResult }) {
  const d = r.resume_data;
  const s = r.section_breakdown ?? [];
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <InfoCard label="Name" value={d?.name} />
        <InfoCard label="Email" value={d?.email} />
        <InfoCard label="Experience" value={`${r.years_experience ?? 0} years`} />
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-semibold mb-4">Section breakdown</h3>
        <div className="space-y-2">
          {s.map((x, i) => (
            <div key={i}>
              <div className="flex justify-between text-sm mb-1">
                <span>{x.section}</span>
                <span className="font-semibold">{x.score}%</span>
              </div>
              <Progress value={x.score} className="h-1.5" />
            </div>
          ))}
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <ResumeCard title="Skills" items={d?.skills} />
        <ResumeCard title="Education" items={d?.education} />
        <ResumeCard title="Certifications" items={d?.certifications} />
        <ResumeCard title="Projects" items={d?.projects} />
        <ResumeCard title="Experience" items={d?.experience} className="md:col-span-2" />
      </div>
    </div>
  );
}
function InfoCard({ label, value }: { label: string; value?: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-semibold truncate">{value || "—"}</div>
    </div>
  );
}
function ResumeCard({ title, items, className }: { title: string; items?: string[]; className?: string }) {
  return (
    <div className={`glass rounded-2xl p-5 ${className ?? ""}`}>
      <h4 className="font-semibold mb-2">{title}</h4>
      {items?.length ? (
        <ul className="text-sm space-y-1 list-disc pl-5">{items.map((x, i) => <li key={i}>{x}</li>)}</ul>
      ) : (
        <div className="text-xs text-muted-foreground">None detected.</div>
      )}
    </div>
  );
}