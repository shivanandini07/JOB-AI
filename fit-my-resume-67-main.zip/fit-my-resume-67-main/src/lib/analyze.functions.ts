import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const InputSchema = z.object({
  resume_text: z.string().min(50, "Resume text is too short"),
  job_description: z.string().min(30, "Job description is too short"),
  job_title: z.string().optional(),
  save: z.boolean().default(true),
});

const SYSTEM = `You are a senior technical recruiter and ATS expert with 15+ years of experience.
Analyze a resume against a job description and produce a rigorous JSON report.
Score numerically (0-100). Be honest and specific. Do NOT invent facts about the candidate.
Use strong action verbs and quantify impact in rewrites.
Return ONLY valid JSON matching the schema — no prose, no markdown fences.`;

function buildPrompt(resume: string, jd: string, jobTitle?: string) {
  return `RESUME:\n"""${resume.slice(0, 15000)}"""\n\nJOB_DESCRIPTION${jobTitle ? ` (title: ${jobTitle})` : ""}:\n"""${jd.slice(0, 8000)}"""\n\nReturn JSON with EXACTLY these keys:
{
  "ats_score": number (0-100 overall),
  "keyword_match": number (0-100),
  "semantic_similarity": number (0-100),
  "skills_match": number (0-100),
  "experience_match": number (0-100),
  "semantic_explanation": string (2-3 sentences explaining why the score was assigned),
  "resume_data": {
    "name": string, "email": string, "phone": string,
    "skills": string[], "education": string[], "certifications": string[],
    "projects": string[], "experience": string[]
  },
  "jd_data": {
    "job_title": string, "required_skills": string[], "qualifications": string[],
    "technologies": string[], "responsibilities": string[], "keywords": string[]
  },
  "matched_keywords": string[],
  "missing_keywords": string[],
  "high_priority_keywords": string[],
  "technical_skills": { "matched": string[], "missing": string[] },
  "soft_skills": { "matched": string[], "missing": string[] },
  "strengths": string[] (4-6 items),
  "weaknesses": string[] (3-5 items),
  "formatting_issues": string[] (2-4 items),
  "ats_compatibility": string[] (2-4 items),
  "suggestions": string[] (5-8 concrete edits),
  "rewritten_bullets": [{ "original": string, "improved": string }] (5-8 pairs using STAR method with metrics),
  "summary": string (2-4 sentence ATS-friendly professional summary tailored to the JD),
  "interview_questions": {
    "hr": [{ "question": string, "difficulty": "easy"|"medium"|"hard", "suggested_answer": string }] (4 items),
    "technical": [ 5 items ],
    "python": [ 3 items ],
    "sql": [ 3 items ],
    "machine_learning": [ 3 items ],
    "behavioral": [ 4 items ],
    "project_based": [ 4 items ]
  },
  "learning_roadmap": [{
    "skill": string, "why": string,
    "courses": string[], "certifications": string[],
    "projects": string[], "docs": string[], "books": string[]
  }] (3-6 items focused on missing skills),
  "readability_score": number (0-100),
  "grammar_notes": string[] (2-4 items),
  "action_verbs": string[] (strong verbs actually used or suggested),
  "years_experience": number (estimated),
  "recruiter_recommendation": string (2-3 sentence hire recommendation),
  "section_breakdown": [{ "section": string, "score": number }] (Summary, Experience, Skills, Education, Projects, Certifications),
  "interview_readiness": number (0-100)
}`;
}

export const runAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => InputSchema.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI is not configured. Please contact support.");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "openai/gpt-5.5",
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: buildPrompt(data.resume_text, data.job_description, data.job_title) },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (res.status === 429) throw new Error("Rate limited. Please try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted. Add credits in your workspace settings.");
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`AI request failed (${res.status}): ${t.slice(0, 300)}`);
    }

    const payload = (await res.json()) as {
      choices: { message: { content: string } }[];
    };
    const content = payload.choices?.[0]?.message?.content ?? "{}";

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let parsed: any;
    try {
      parsed = JSON.parse(content);
    } catch {
      throw new Error("AI returned invalid JSON. Please try again.");
    }

    let analysisId: string | null = null;
    if (data.save) {
      const title = parsed?.jd_data?.job_title || data.job_title || "Untitled analysis";
      const { data: row, error } = await context.supabase
        .from("analyses")
        .insert({
          user_id: context.userId,
          title,
          resume_text: data.resume_text,
          job_description: data.job_description,
          job_title: data.job_title ?? title,
          ats_score: Math.round(Number(parsed.ats_score) || 0),
          result: parsed,
        })
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      analysisId = row.id;
    }

    // Serialize as JSON string to keep RPC types happy; client parses.
    return { analysisId, result_json: JSON.stringify(parsed) };
  });