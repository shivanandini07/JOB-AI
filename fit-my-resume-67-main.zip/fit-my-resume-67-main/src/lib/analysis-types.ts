export type Difficulty = "easy" | "medium" | "hard";

export interface InterviewQuestion {
  question: string;
  difficulty: Difficulty;
  suggested_answer?: string;
}

export interface RoadmapItem {
  skill: string;
  why: string;
  courses: string[];
  certifications: string[];
  projects: string[];
  docs: string[];
  books: string[];
}

export interface AnalysisResult {
  ats_score: number;
  keyword_match: number;
  semantic_similarity: number;
  skills_match: number;
  experience_match: number;
  semantic_explanation: string;

  resume_data: {
    name: string;
    email: string;
    phone?: string;
    skills: string[];
    education: string[];
    certifications: string[];
    projects: string[];
    experience: string[];
  };

  jd_data: {
    job_title: string;
    required_skills: string[];
    qualifications: string[];
    technologies: string[];
    responsibilities: string[];
    keywords: string[];
  };

  matched_keywords: string[];
  missing_keywords: string[];
  high_priority_keywords: string[];
  technical_skills: { matched: string[]; missing: string[] };
  soft_skills: { matched: string[]; missing: string[] };

  strengths: string[];
  weaknesses: string[];
  formatting_issues: string[];
  ats_compatibility: string[];
  suggestions: string[];

  rewritten_bullets: { original: string; improved: string }[];
  summary: string;

  interview_questions: {
    hr: InterviewQuestion[];
    technical: InterviewQuestion[];
    python: InterviewQuestion[];
    sql: InterviewQuestion[];
    machine_learning: InterviewQuestion[];
    behavioral: InterviewQuestion[];
    project_based: InterviewQuestion[];
  };

  learning_roadmap: RoadmapItem[];

  readability_score: number;
  grammar_notes: string[];
  action_verbs: string[];
  years_experience: number;
  recruiter_recommendation: string;

  section_breakdown: { section: string; score: number }[];
  interview_readiness: number;
}